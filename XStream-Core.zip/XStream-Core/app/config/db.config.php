<?php
/**
 * Define database credentials
 * 
*/
define("DB_HOST", "TEMP_HOST"); 
define("DB_NAME", "TEMP_NAME");
define("DB_USER", "TEMP_USER"); 
define("DB_PASS", "TEMP_PASS"); 
define("DB_ENCODING", "utf8");