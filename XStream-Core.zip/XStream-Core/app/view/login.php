<?php require PATH . '/view/admin/common/head.php'; ?>
<?php require PATH . '/view/admin/common/header.php'; ?>
<?php require PATH . '/view/admin/common/javascript.php'; ?>
<?php require PATH . '/view/admin/common/footer.php'; ?>